
# Discord Webhook Messenger

A sleek, minimalist Discord webhook messenger application inspired by Apple's design principles.

## Features

- Send customized messages to Discord webhooks
- Set custom username and avatar URL for webhook messages
- Send multiple messages with configurable delay
- Modern, clean user interface with smooth animations
- Test message functionality

## Requirements

- Python 3.6 or higher
- Required packages (install with `pip install -r requirements.txt`):
  - tkinter (usually comes with Python)
  - Pillow
  - requests

## Usage

1. Run the application:
   ```
   python main.py
   ```

2. Enter your Discord webhook URL
3. Customize your message, username, and avatar (if desired)
4. Select the number of messages and delay between them
5. Click "Send Messages" to start sending or "Send Test Message" to test your configuration

## Notes

- Tkinter is typically included with Python installations
- For macOS users, you may need to install Tkinter separately if it's not included with your Python installation
- The application requires an active internet connection to send messages

## Disclaimer

This application is for educational purposes only. Please use responsibly and in accordance with Discord's terms of service.

