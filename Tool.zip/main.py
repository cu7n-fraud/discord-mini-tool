import tkinter as tk
from tkinter import ttk, messagebox, scrolledtext
import requests
import json
import threading
import time
from PIL import Image, ImageTk
import os
import sys
import random

class ModernUI(tk.Tk):
    def __init__(self):
        super().__init__()
        
        self.title("Discord Webhook Messenger by cu7n")
        self.geometry("800x600")
        self.minsize(800, 600)
        
        self.bg_color = "#F5F5F7"
        self.accent_color = "#0071E3"
        self.text_color = "#1D1D1F"
        self.secondary_text = "#86868B"
        
        self.configure(bg=self.bg_color)
        
        self.font_title = ("Helvetica", 24, "bold")
        self.font_subtitle = ("Helvetica", 16)
        self.font_regular = ("Helvetica", 12)
        self.font_small = ("Helvetica", 10)
        
        self.style = ttk.Style(self)
        self.style.configure("TFrame", background=self.bg_color)
        self.style.configure("TLabel", background=self.bg_color, foreground=self.text_color)
        self.style.configure("TButton", 
                             font=self.font_regular, 
                             background=self.accent_color, 
                             foreground="white",
                             padding=10)
        
        self.style.map("TButton",
                      foreground=[('pressed', 'white'), ('active', 'white')],
                      background=[('pressed', '#005BBF'), ('active', '#3392FF')])
        
        self.webhook_url = tk.StringVar()
        self.message_content = tk.StringVar()
        self.username = tk.StringVar()
        self.avatar_url = tk.StringVar()
        self.delay = tk.DoubleVar(value=1.0)
        self.message_count = tk.IntVar(value=1)
        self.is_running = False
        self.stop_thread = False
        
        self.create_header()
        self.create_content()
        self.create_footer()
        
        self.animate_startup()
        
    def create_header(self):
        """Create the header with title and description"""
        header = ttk.Frame(self)
        header.pack(fill=tk.X, padx=40, pady=(40, 20))
        
        title_frame = ttk.Frame(header)
        title_frame.pack(anchor=tk.W)
        
        subtitle = ttk.Label(title_frame, text="DISCORD", 
                          font=self.font_small, 
                          foreground=self.accent_color)
        subtitle.pack(anchor=tk.W)
        
        title = ttk.Label(title_frame, text="Webhook Messenger", 
                       font=self.font_title)
        title.pack(anchor=tk.W)
        
        description = ttk.Label(header, 
                             text="Send customized messages to Discord channels through webhooks with elegance and precision.",
                             font=self.font_subtitle,
                             foreground=self.secondary_text,
                             wraplength=700)
        description.pack(anchor=tk.W, pady=(10, 0))
        
    def create_content(self):
        """Create the main content area with form elements"""
        content = ttk.Frame(self)
        content.pack(fill=tk.BOTH, expand=True, padx=40, pady=20)
        
        left_column = ttk.Frame(content)
        left_column.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(0, 10))
        
        self.create_input_group(left_column, "Webhook URL", self.webhook_url)
        
        self.create_input_group(left_column, "Username (optional)", self.username)
        
        self.create_input_group(left_column, "Avatar URL (optional)", self.avatar_url)
        
        message_frame = ttk.Frame(left_column)
        message_frame.pack(fill=tk.X, pady=10)
        
        message_label = ttk.Label(message_frame, text="Message Content", font=self.font_regular)
        message_label.pack(anchor=tk.W, pady=(0, 5))
        
        self.message_text = scrolledtext.ScrolledText(message_frame, height=8, 
                                                  font=self.font_regular,
                                                  bg="white",
                                                  relief=tk.FLAT)
        self.message_text.pack(fill=tk.X)
        
        right_column = ttk.Frame(content)
        right_column.pack(side=tk.RIGHT, fill=tk.Y, padx=(10, 0))
        
        count_frame = ttk.Frame(right_column)
        count_frame.pack(fill=tk.X, pady=10)
        
        count_label = ttk.Label(count_frame, text="Number of Messages", font=self.font_regular)
        count_label.pack(anchor=tk.W, pady=(0, 5))
        
        count_spinbox = ttk.Spinbox(count_frame, from_=1, to=1000, textvariable=self.message_count,
                               font=self.font_regular, width=10)
        count_spinbox.pack(fill=tk.X)
        
        delay_frame = ttk.Frame(right_column)
        delay_frame.pack(fill=tk.X, pady=10)
        
        delay_label = ttk.Label(delay_frame, text="Delay (seconds)", font=self.font_regular)
        delay_label.pack(anchor=tk.W, pady=(0, 5))
        
        delay_spinbox = ttk.Spinbox(delay_frame, from_=0.1, to=60, increment=0.1, 
                               textvariable=self.delay,
                               font=self.font_regular, width=10)
        delay_spinbox.pack(fill=tk.X)
        
        button_frame = ttk.Frame(right_column)
        button_frame.pack(fill=tk.X, pady=20)
        
        self.send_button = tk.Button(button_frame, text="Send Messages",
                                 bg=self.accent_color,
                                 fg="white",
                                 font=self.font_regular,
                                 relief=tk.FLAT,
                                 padx=20, pady=10,
                                 command=self.start_sending)
        self.send_button.pack(fill=tk.X, pady=5)
        
        self.stop_button = tk.Button(button_frame, text="Stop",
                                  bg="#FF3B30",
                                  fg="white",
                                  font=self.font_regular,
                                  relief=tk.FLAT,
                                  padx=20, pady=10,
                                  state=tk.DISABLED,
                                  command=self.stop_sending)
        self.stop_button.pack(fill=tk.X, pady=5)
        
        self.test_button = tk.Button(button_frame, text="Send Test Message",
                                  bg="#34C759",
                                  fg="white",
                                  font=self.font_regular,
                                  relief=tk.FLAT,
                                  padx=20, pady=10,
                                  command=self.send_test)
        self.test_button.pack(fill=tk.X, pady=5)
        
        status_frame = ttk.Frame(right_column)
        status_frame.pack(fill=tk.X, pady=10)
        
        status_label = ttk.Label(status_frame, text="Status", font=self.font_regular)
        status_label.pack(anchor=tk.W, pady=(0, 5))
        
        self.status_var = tk.StringVar(value="Ready")
        status = ttk.Label(status_frame, textvariable=self.status_var, 
                        font=self.font_regular,
                        foreground=self.secondary_text)
        status.pack(anchor=tk.W)
        
    def create_footer(self):
        """Create footer with copyright notice"""
        footer = ttk.Frame(self)
        footer.pack(fill=tk.X, padx=40, pady=20)
        
        copyright = ttk.Label(footer, text="© 2023 Webhook Messenger. All rights reserved.",
                           font=self.font_small,
                           foreground=self.secondary_text)
        copyright.pack(side=tk.LEFT)
        
    def create_input_group(self, parent, label_text, variable):
        """Helper to create consistent input groups"""
        frame = ttk.Frame(parent)
        frame.pack(fill=tk.X, pady=10)
        
        label = ttk.Label(frame, text=label_text, font=self.font_regular)
        label.pack(anchor=tk.W, pady=(0, 5))
        
        entry = ttk.Entry(frame, textvariable=variable, font=self.font_regular)
        entry.pack(fill=tk.X)
        
    def animate_startup(self):
        """Simple animation on startup"""
        current_alpha = 0.0
        self.attributes('-alpha', current_alpha)
        
        def fade_in():
            nonlocal current_alpha
            current_alpha += 0.1
            self.attributes('-alpha', min(current_alpha, 1.0))
            if current_alpha < 1.0:
                self.after(20, fade_in)
        
        self.after(10, fade_in)
    
    def start_sending(self):
        """Start sending messages in a separate thread"""
        if not self.webhook_url.get():
            messagebox.showerror("Error", "Please enter a webhook URL")
            return
            
        if not self.message_text.get("1.0", tk.END).strip():
            messagebox.showerror("Error", "Please enter a message")
            return
        
        self.is_running = True
        self.stop_thread = False
        self.send_button.config(state=tk.DISABLED)
        self.test_button.config(state=tk.DISABLED)
        self.stop_button.config(state=tk.NORMAL)
        
        thread = threading.Thread(target=self.send_messages, daemon=True)
        thread.start()
    
    def stop_sending(self):
        """Stop the sending process"""
        self.stop_thread = True
        self.status_var.set("Stopping...")
    
    def send_test(self):
        """Send a single test message"""
        if not self.webhook_url.get():
            messagebox.showerror("Error", "Please enter a webhook URL")
            return
            
        if not self.message_text.get("1.0", tk.END).strip():
            messagebox.showerror("Error", "Please enter a message")
            return
        
        thread = threading.Thread(target=self.send_single_message, daemon=True)
        thread.start()
    
    def send_messages(self):
        """Send multiple messages according to settings"""
        try:
            count = self.message_count.get()
            delay = self.delay.get()
            
            for i in range(count):
                if self.stop_thread:
                    break
                    
                self.after(0, lambda i=i, c=count: self.status_var.set(f"Sending message {i+1}/{c}"))
                success = self.send_single_message(show_result=False)
                
                if not success and not self.stop_thread:
                    self.after(0, lambda i=i, c=count: self.status_var.set(f"Error occurred. Stopped at {i+1}/{c}"))
                    break
                    
                if i < count - 1 and not self.stop_thread:
                    time.sleep(delay)
            
            self.after(0, self.reset_ui)
            
        except Exception as e:
            self.after(0, lambda e=e: self.handle_error(e))
    
    def reset_ui(self):
        """Reset UI elements after sending is complete"""
        self.send_button.config(state=tk.NORMAL)
        self.test_button.config(state=tk.NORMAL)
        self.stop_button.config(state=tk.DISABLED)
        self.is_running = False
        
        if not self.stop_thread:
            self.status_var.set(f"Complete! Sent {self.message_count.get()} messages.")
        else:
            self.status_var.set("Stopped by user.")
    
    def handle_error(self, error):
        """Handle unexpected errors"""
        self.send_button.config(state=tk.NORMAL)
        self.test_button.config(state=tk.NORMAL)
        self.stop_button.config(state=tk.DISABLED)
        self.is_running = False
        self.status_var.set(f"Error: {str(error)}")
        messagebox.showerror("Error", str(error))
    
    def send_single_message(self, show_result=True):
        """Send a single message to the webhook"""
        try:
            url = self.webhook_url.get()
            content = self.message_text.get("1.0", tk.END).strip()
            username = self.username.get()
            avatar_url = self.avatar_url.get()
            
            payload = {"content": content}
            
            if username:
                payload["username"] = username
            if avatar_url:
                payload["avatar_url"] = avatar_url
                
            response = requests.post(url, json=payload)
            
            if response.status_code == 204:
                if show_result:
                    self.after(0, lambda: self.status_var.set("Test message sent successfully!"))
                return True
            else:
                error_text = f"Error: HTTP {response.status_code}"
                try:
                    error_data = response.json()
                    if "message" in error_data:
                        error_text += f" - {error_data['message']}"
                except:
                    pass
                
                if show_result:
                    self.after(0, lambda text=error_text: self.status_var.set(text))
                    self.after(0, lambda text=error_text: messagebox.showerror("Error", text))
                return False
                
        except Exception as e:
            if show_result:
                self.after(0, lambda e=e: self.status_var.set(f"Error: {str(e)}"))
                self.after(0, lambda e=e: messagebox.showerror("Error", str(e)))
            return False

def main():
    try:
        app = ModernUI()
        app.mainloop()
    except Exception as e:
        print(f"Error starting application: {str(e)}")
        messagebox.showerror("Application Error", f"Failed to start: {str(e)}")

if __name__ == "__main__":
    main()
